package co.adityarajput.notifilter.viewmodels

import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import co.adityarajput.notifilter.R
import co.adityarajput.notifilter.data.Cache
import co.adityarajput.notifilter.data.Repository
import co.adityarajput.notifilter.data.models.*
import co.adityarajput.notifilter.services.NotificationListener
import co.adityarajput.notifilter.utils.Logger
import co.adityarajput.notifilter.utils.containsMatchIn
import co.adityarajput.notifilter.utils.evaluateAgainst
import co.adityarajput.notifilter.utils.isValidRegex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.time.Duration.Companion.milliseconds

class UpsertFilterViewModel(
    filter: Filter?,
    private val repository: Repository,
    packageManager: PackageManager,
) : ViewModel() {
    data class State(
        val page: FormPage = FormPage.ZAPPER,
        val values: Values = Values(),
        val error: FormError? = null,
        val warnings: List<FormWarning> = listOf(),
    )

    data class Values(
        val filterId: Int = 0,
        val notification: Notification? = null,
        val app: App = None,
        val regexTarget: RegexTarget = RegexTarget.OR,
        val queryPattern: String = "",
        val secondaryQueryPattern: String = "",
        val action: Action = Action.DISMISS,
        val schedule: Schedule = Schedule(),
        val historyEnabled: Boolean = true,
        val widgetEnabled: Boolean = false,
        val priority: Int = 0,
        val cooldown: Long? = null,
    ) {
        constructor(filter: Filter) : this(
            filter.id, null, filter.app, filter.regexTarget,
            filter.regexPattern, filter.secondaryRegexPattern ?: "",
            filter.action, filter.schedule, filter.historyEnabled, filter.widgetEnabled,
            filter.priority, filter.cooldown,
        )

        fun toFilter() = Filter(
            app, queryPattern, action, regexTarget,
            if (regexTarget == RegexTarget.AND) secondaryQueryPattern else null,
            schedule, true, historyEnabled, widgetEnabled,
            if (filterId == 0) Int.MAX_VALUE else priority, if (cooldown == 0L) null else cooldown,
            id = filterId,
        )
    }

    var state by mutableStateOf(
        if (filter == null) State()
        else State(FormPage.PACKAGE, Values(filter), null),
    )

    var visibleApps by mutableStateOf<List<App>>(emptyList())

    var allPackages by mutableStateOf<List<App>>(emptyList())

    var activeNotifications by mutableStateOf(NotificationListener.instance.activeNotifications)

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                allPackages = Cache.getAllPackages(packageManager)
                visibleApps = Cache.getVisibleApps(packageManager)
            }

            while (true) {
                activeNotifications = NotificationListener.instance.activeNotifications
                delay(500.milliseconds)
            }
        }
    }

    fun updateForm(page: FormPage, values: Values) {
        state = State(page, values, getError(page, values), getWarnings(page, values))
    }

    private fun getError(
        page: FormPage = state.page,
        values: Values = state.values,
    ): FormError? {
        when (page) {
            FormPage.ZAPPER -> return null

            FormPage.PACKAGE -> if (values.app == None) return FormError.BLANK_FIELDS

            FormPage.PATTERN -> {
                if (values.queryPattern.isBlank()) return FormError.BLANK_FIELDS

                if (values.regexTarget != RegexTarget.EXPRESSION) {
                    if (!values.queryPattern.isValidRegex()) return FormError.INVALID_NOTIFICATION_REGEX

                    if (values.regexTarget == RegexTarget.AND) {
                        if (values.secondaryQueryPattern.isBlank()) return FormError.BLANK_FIELDS
                        if (!values.secondaryQueryPattern.isValidRegex()) return FormError.INVALID_NOTIFICATION_REGEX
                    }
                } else {
                    try {
                        values.queryPattern.evaluateAgainst(values.notification)
                    } catch (_: Exception) {
                        return FormError.INVALID_EXPRESSION
                    }
                }
            }

            FormPage.ACTION -> {
                when (values.action) {
                    is Action.TAP_BUTTON -> {
                        if (values.action.buttonRegex.isBlank())
                            return FormError.BLANK_FIELDS

                        if (!values.action.buttonRegex.isValidRegex())
                            return FormError.INVALID_BUTTON_REGEX
                    }

                    /**
                     * 30 minutes to 12 hours
                     */
                    is Action.BATCH if values.action.batchLength !in 0.5..12.0 -> return FormError.INVALID_BATCH_LENGTH

                    /**
                     * One minute to one day
                     */
                    is Action.DELAY -> {
                        if (values.action.delayLength != null && values.action.delayLength !in 1.0..24 * 60.0)
                            return FormError.INVALID_DELAY_LENGTH
                    }

                    is Action.DEBOUNCE -> {
                        if (values.app == Any)
                            return FormError.CANT_DEBOUNCE_ANY

                        /**
                         * One minute to one day
                         */
                        if (values.action.cooldownLength !in 1.0..24 * 60.0)
                            return FormError.INVALID_COOLDOWN_LENGTH
                    }

                    /**
                     * One second to one minute
                     */
                    is Action.ALERT if values.action.alertLifespan !in 1.0..60.0 -> return FormError.INVALID_ALERT_LIFESPAN

                    /**
                     * One minute to one day
                     */
                    is Action.DISTURB if values.action.pauseLength !in 1.0..24 * 60.0 -> return FormError.INVALID_PAUSE_LENGTH

                    /**
                     * One minute to one day
                     */
                    is Action.DISMISS_STALE if values.action.retentionLength !in 1.0..24 * 60.0 -> return FormError.INVALID_RETENTION_LENGTH

                    else -> {}
                }
            }

            FormPage.SCHEDULE -> {
                if (!values.schedule.isRangeValid()) return FormError.INVALID_TIME_RANGE
                if (values.schedule.days.isEmpty()) return FormError.BLANK_FIELDS
                if (values.cooldown != null && values.cooldown !in 1..<86_400_000L) return FormError.INVALID_FILTER_COOLDOWN_LENGTH
            }
        }
        return null
    }

    private fun getWarnings(
        page: FormPage = state.page,
        values: Values = state.values,
    ): List<FormWarning> {
        if (page != FormPage.PATTERN || values.notification == null) return listOf()

        try {
            val regexTarget = values.regexTarget
            val notification = values.notification

            if (regexTarget == RegexTarget.EXPRESSION) {
                return if (values.queryPattern.evaluateAgainst(notification)) emptyList() else
                    listOf(FormWarning.EXPRESSION_DOESNT_MATCH_NOTIFICATION)
            }

            val warnings = mutableListOf<FormWarning>()
            if (
                regexTarget != RegexTarget.CONTENT
                && !values.queryPattern.containsMatchIn(notification.title)
            ) warnings.add(FormWarning.REGEX_DOESNT_MATCH_TITLE)
            if (
                (regexTarget == RegexTarget.CONTENT || regexTarget == RegexTarget.OR)
                && !values.queryPattern.containsMatchIn(notification.content)
            ) warnings.add(FormWarning.REGEX_DOESNT_MATCH_CONTENT)
            if (
                regexTarget == RegexTarget.AND &&
                !values.secondaryQueryPattern.containsMatchIn(notification.content)
            ) warnings.add(FormWarning.REGEX_DOESNT_MATCH_CONTENT)

            return warnings
        } catch (_: Exception) {
            return listOf()
        }
    }

    suspend fun submitForm() {
        if (getError() == null) {
            val filter = state.values.toFilter()
            Logger.d(
                "FiltersViewModel.submitForm",
                "${if (state.values.filterId == 0) "Adding" else "Updating"} $filter",
            )
            repository.upsert(filter)
        }
    }
}

enum class FormPage {
    ZAPPER, PACKAGE, PATTERN, ACTION, SCHEDULE;

    fun isFirstPage() = this == ZAPPER

    fun isFinalPage() = this == SCHEDULE

    fun next() = entries[ordinal + 1]

    fun previous() = entries[ordinal - 1]
}

enum class FormError {
    BLANK_FIELDS,
    INVALID_NOTIFICATION_REGEX,
    INVALID_EXPRESSION,
    INVALID_BUTTON_REGEX,
    INVALID_BATCH_LENGTH,
    INVALID_DELAY_LENGTH,
    CANT_DEBOUNCE_ANY,
    INVALID_COOLDOWN_LENGTH,
    INVALID_ALERT_LIFESPAN,
    INVALID_PAUSE_LENGTH,
    INVALID_RETENTION_LENGTH,
    INVALID_TIME_RANGE,
    INVALID_FILTER_COOLDOWN_LENGTH,
}

enum class FormWarning(val description: Int) {
    REGEX_DOESNT_MATCH_TITLE(R.string.pattern_doesnt_match_title),
    REGEX_DOESNT_MATCH_CONTENT(R.string.pattern_doesnt_match_content),
    EXPRESSION_DOESNT_MATCH_NOTIFICATION(R.string.expression_doesnt_match_notification),
}
