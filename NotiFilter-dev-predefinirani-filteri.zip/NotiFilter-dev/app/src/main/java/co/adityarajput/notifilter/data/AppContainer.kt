package co.adityarajput.notifilter.data

import android.content.Context
import co.adityarajput.notifilter.data.models.*
import co.adityarajput.notifilter.services.Preferences
import co.adityarajput.notifilter.utils.Logger
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json

private const val DEFAULT_FILTERS_ASSET = "default_filters.json"

class AppContainer(private val context: Context) {
    val repository: Repository by lazy {
        Repository(
            NotiFilterDatabase.getDatabase(context).filterDao(),
            NotiFilterDatabase.getDatabase(context).notificationDao(),
        )
    }

    suspend fun export() =
        Json.encodeToString<List<Filter>>(repository.filters().first())

    suspend fun import(json: String) =
        repository.deleteAndCreateFilters(*Json.decodeFromString<Array<Filter>>(json))

    /**
     * Učitava predefinirane filtere iz app/src/main/assets/default_filters.json
     * (isti format kao Export/Import u aplikaciji). Izvršava se samo jednom –
     * pri prvom pokretanju, ako je baza filtera prazna.
     */
    fun seedDefaultFilters() {
        if (Preferences.defaultFiltersSeeded) return

        runBlocking {
            if (repository.filters().first().isEmpty()) {
                try {
                    val json = context.assets.open(DEFAULT_FILTERS_ASSET)
                        .bufferedReader().use { it.readText() }
                    repository.upsert(*Json.decodeFromString<Array<Filter>>(json))
                    Logger.d("AppContainer", "Seeded default filters from $DEFAULT_FILTERS_ASSET")
                } catch (e: Exception) {
                    Logger.e("AppContainer", "Failed to seed default filters", e)
                    return@runBlocking
                }
            }
            Preferences.defaultFiltersSeeded = true
        }
    }

    fun seedDemoData() {
        runBlocking {
            if (
                repository.filters().first().isEmpty() &&
                repository.notifications().first().isEmpty()
            ) {
                repository.upsert(
                    Filter(
                        App("Clock", "com.google.android.deskclock"),
                        "Upcoming alarm",
                        Action.DISMISS,
                        RegexTarget.TITLE,
                        hits = 87,
                    ),
                    Filter(
                        App("Gmail", "com.google.android.gm"),
                        "Verify your identity",
                        Action.TAP_NOTIFICATION,
                        RegexTarget.CONTENT,
                        enabled = false,
                    ),
                    Filter(
                        App("Software update", "com.wssyncmldm"),
                        "software update",
                        Action.TAP_BUTTON("Remind me"),
                        RegexTarget.CONTENT,
                        schedule = Schedule(days = setOf(2, 3, 4, 5, 6)),
                        hits = 23,
                    ),
                    Filter(
                        App("Gmail", "com.google.android.gm"),
                        "[Nn]ewsletter",
                        Action.BATCH(3.0),
                        RegexTarget.OR,
                        widgetEnabled = true,
                        hits = 1,
                    ),
                    Filter(
                        App("WhatsApp", "com.whatsapp"),
                        "Book Club",
                        Action.DELAY(),
                        RegexTarget.AND,
                        "^Bob",
                        schedule = Schedule(start = 9 * 60, end = 17 * 60),
                        hits = 15,
                    ),
                    Filter(
                        App("WhatsApp", "com.whatsapp"),
                        "Photo",
                        Action.DEBOUNCE(1.0),
                        RegexTarget.CONTENT,
                        historyEnabled = false,
                    ),
                    Filter(
                        App("Tumblr", "com.tumblr"),
                        "poll",
                        Action.MUTE,
                        RegexTarget.CONTENT,
                        hits = 17,
                        widgetEnabled = true,
                    ),
                    Filter(
                        App("F-Droid", "org.fdroid"),
                        "Update available",
                        Action.ALERT(2.0),
                        RegexTarget.AND,
                        "NotiFilter|Alarmetrics|FileFlow",
                        historyEnabled = false,
                    ),
                    Filter(
                        Any,
                        "urgent",
                        Action.DISTURB(5.0),
                        RegexTarget.OR,
                        historyEnabled = false,
                    ),
                    Filter(
                        App("Twitch", "tv.twitch.android.app"),
                        "live",
                        Action.DISMISS_STALE(60.0),
                        RegexTarget.OR,
                        historyEnabled = false,
                    ),
                    Filter(
                        App("GitHub", "com.github.android"),
                        """titleMatches("approved your pull request")""",
                        Action.REPLACE("PR approved", $$"${content}"),
                        RegexTarget.EXPRESSION,
                        historyEnabled = false,
                    ),
                    Filter(
                        App("MinCal", "co.adityarajput.mincal"),
                        ".+",
                        Action.READ($$"Event Reminder: ${title}"),
                        RegexTarget.TITLE,
                        historyEnabled = false,
                    ),
                )
                repository.upsert(
                    Notification(
                        "Download paused",
                        "A software update is available.",
                        "Software update",
                        System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000,
                    ),
                    Notification(
                        "Upcoming alarm",
                        "Wed 8:30 AM - Wake up",
                        "Clock",
                        System.currentTimeMillis() - 28 * 60 * 60 * 1000,
                    ),
                    Notification(
                        "Upcoming alarm",
                        "Wed 11:30 AM - Exercise",
                        "Clock",
                        System.currentTimeMillis() - 25 * 60 * 60 * 1000,
                    ),
                    Notification(
                        "tom@newsletter.tomscott.com",
                        "The week: a microphone, a ropeway, and something very sour. Hello! Over the last few days...",
                        "Gmail",
                        System.currentTimeMillis() - 3 * 60 * 60 * 1000,
                        showInWidget = true,
                    ),
                    Notification(
                        "Book Club",
                        "Bob: Please go for something lighter this time. I'm tired of tomes!",
                        "WhatsApp",
                        System.currentTimeMillis() - 37 * 60 * 1000,
                    ),
                    Notification(
                        "Poll finale alert",
                        "Check the poll results for \"Do you pronounce Z as Zed?\".",
                        "Tumblr",
                        System.currentTimeMillis() - 3 * 60 * 1000,
                    ),
                )
            }
        }
    }
}
