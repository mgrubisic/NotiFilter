package co.adityarajput.notifilter.data

import androidx.room.*
import co.adityarajput.notifilter.data.models.Filter
import kotlinx.coroutines.flow.Flow

@Dao
interface FilterDao {
    @Upsert
    suspend fun upsert(vararg filters: Filter)

    @Transaction
    suspend fun deleteAndCreateAll(vararg filters: Filter) {
        deleteAll()
        upsert(*filters)
    }

    @Query("SELECT * from filters ORDER BY priority, id")
    fun list(): Flow<List<Filter>>

    @Query("UPDATE filters SET hits = hits + 1 WHERE id = :id")
    suspend fun registerHit(id: Int)

    @Query("UPDATE filters SET historyEnabled = 1 - historyEnabled, hits = 0 WHERE id = :id")
    suspend fun toggleHistory(id: Int)

    @Query("UPDATE filters SET enabled = 1 - enabled WHERE id = :id")
    suspend fun toggleEnabled(id: Int)

    @Delete
    suspend fun delete(filter: Filter)

    @Query("DELETE FROM filters")
    suspend fun deleteAll()
}
