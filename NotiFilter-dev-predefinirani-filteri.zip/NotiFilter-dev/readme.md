<img width="192" height="192" alt="NotiFilter app icon" src="https://github.com/BURG3R5/NotiFilter/blob/dev/metadata/en-US/images/icon.png" />

![F-Droid downloads](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fgithub.com%2Fkitswas%2Ffdroid-metrics-dashboard%2Fraw%2Frefs%2Fheads%2Fmain%2Fprocessed%2Ftotal%2Fco.adityarajput.notifilter.json&query=%24.total_downloads&logo=fdroid&style=flat-square&label=F-Droid%20downloads) ![GitHub downloads](https://img.shields.io/github/downloads/BURG3R5/NotiFilter/total?style=flat-square&logo=github&label=GitHub%20downloads)

# NotiFilter

**Silence annoying notifications**

NotiFilter listens to all device notifications and quietly manages those that match your filters.

[<img src="https://f-droid.org/badge/get-it-on.png" alt="Get it on F-Droid" height="80">](https://f-droid.org/packages/co.adityarajput.notifilter) [<img src="https://gitlab.com/IzzyOnDroid/repo/-/raw/master/assets/IzzyOnDroid.png" height="80" alt="Get it at IzzyOnDroid">](https://apt.izzysoft.de/packages/co.adityarajput.notifilter) [<img src="https://github.com/user-attachments/assets/713d71c5-3dec-4ec4-a3f2-8d28d025a9c6" alt="Get it on Obtainium" height="80">](https://apps.obtainium.imranr.dev/redirect?r=obtainium://add/https://github.com/BURG3R5/NotiFilter)

## Screenshots

<img alt="NotiFilter screenshot: filters screen" src="https://github.com/BURG3R5/NotiFilter/blob/dev/metadata/en-US/images/phoneScreenshots/1.png" width=30%> <img alt="NotiFilter screenshot: block history" src="https://github.com/BURG3R5/NotiFilter/blob/dev/metadata/en-US/images/phoneScreenshots/2.png" width=30%>

## Features

- **Filters** - Use [regex](https://github.com/BURG3R5/NotiFilter/wiki/Examples) to precisely target
  annoying notifications from
  each app 🎯
- **Actions** - Choose what to do with the filtered notifications ⚙
    1. Dismiss it 🚫
    2. Tap it ✅
    3. Tap a button 🔽️
    4. Delay it ⏳
    5. Collect into batches 📦
    6. Debounce it ❄
    7. Mute it 🔇
    8. Play an alert 🔔
    9. Disable DND mode 🔊
    10. Remove after a delay ⏲️
    11. Replace with a custom notification 📝
    12. Read it aloud 🗣
- **Schedule** - Choose when filters run (e.g. only during work hours) and how often (i.e. apply a
  filter-level cooldown) ⏰
- **History** - Recently filtered notifications are stored locally, for reference and retrieval 🧾
- **Widget** - Configure filters to send notifications to a home screen widget 📱
- **Export/Import** - Backup or transfer your filters as JSON files 📂
- **Free, open-source & private**
    - No ads, subscriptions, or in-app purchases 🆓
    - Licensed under the [GPLv3](https://github.com/BURG3R5/notifilter/blob/dev/LICENSE) 📃
    - Fully offline; your data never leaves your device 🔐
- **Lightweight** - Runs in the background with minimal battery and memory usage ⏩

## Usage

Refer to the [wiki](https://github.com/BURG3R5/NotiFilter/wiki) for instructions, examples, tips,
and FAQs.

## Verification

Package ID: `co.adityarajput.notifilter`

SHA256 hash of signing certificate:
`56:0A:30:9B:4F:01:AC:3D:28:65:EA:C6:E3:C3:35:59:EC:C7:E9:AD:8E:A7:9E:CD:58:D2:56:B4:B6:45:8A:0E`
